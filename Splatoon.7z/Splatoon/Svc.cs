﻿using Dalamud.Data;
using Dalamud.Game;
using Dalamud.Game.ClientState;
using Dalamud.Game.ClientState.Buddy;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Fates;
using Dalamud.Game.ClientState.JobGauge;
using Dalamud.Game.ClientState.Keys;
using Dalamud.Game.ClientState.Objects;
using Dalamud.Game.ClientState.Party;
using Dalamud.Game.Command;
using Dalamud.Game.Gui;
using Dalamud.Game.Gui.FlyText;
using Dalamud.Game.Gui.PartyFinder;
using Dalamud.Game.Gui.Toast;
using Dalamud.Game.Libc;
using Dalamud.Game.Network;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.IoC;
using Dalamud.Plugin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Splatoon
{
    class Svc
    {
        [PluginService] [RequiredVersion("1.0")] static internal DalamudPluginInterface pluginInterface { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal BuddyList buddies { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal ChatGui chat { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal ChatHandlers chatHandlers { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal ClientState clientState { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal CommandManager commands { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal Condition condition { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal DataManager data { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal FateTable fates { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal FlyTextGui flyText { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal Framework framework { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal GameGui gameGui { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal GameNetwork gameNetwork { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal JobGauges gauges { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal KeyState keyState { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal LibcFunction libcFunction { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal ObjectTable objects { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal PartyFinderGui pfGui { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal PartyList party { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal SeStringManager seStringManager { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal SigScanner sigScanner { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal TargetManager targets { get; private set; }
        [PluginService] [RequiredVersion("1.0")] static internal ToastGui toasts { get; private set; }
    }
}
